// 单独的模块
define(()=>{
	return {
		say(){
			console.warn('parent module')
		}
	}
})