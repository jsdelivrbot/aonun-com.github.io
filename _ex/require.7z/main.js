define(['jquery'], ($)=>{
	$('<div>').text('main.js 中的代码执行成功').appendTo('body')
})