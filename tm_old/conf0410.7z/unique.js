var fs=require('fs')
var tmtool=require('./tmtool.js');
require('./extend.prototype.js');
var noSpaceEqual=require('./nospaceequal.js');



var all =fs.readFileSync('all.txt',{flag:'r',encoding:'UTF-8'});
all=all.split('\n').filter(e=>e.trim().length>0);


var dict=fs.readFileSync('dict.txt',{flag:'r',encoding:'UTF-8'});
dict=dict.split('\n').map(e=>e.split('\t',1)[0]).filter(e=>e.trim().length>0);


var rs=all.diff(dict);

fs.writeFileSync('uniq.txt', rs.join('\n'), {encoding:'utf8'});