function noSpaceEqual(a,b) {
	a=a.split('').map(function(e){return /\s+/.test(e) ? '' : e.replace(/[\^\$\.\|\/\\\*\+\?\{\}\[\]\(\)\-]/g,'\\$&'); }).join('\\s*')
	a='^\\s*'+a+'\\s*$';
	
	try{
		var r= b.search(a)!==-1;
	}catch(err){
		console.log(b,a)
		console.log(err)
	}
	return r;
}





// var b=noSpaceEqual(' a a a','  a    a  a        ')
// console.log(b)

module.exports=noSpaceEqual;