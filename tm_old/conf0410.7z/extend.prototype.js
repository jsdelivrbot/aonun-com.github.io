var noSpaceEqual = require('./noSpaceEqual.js');

Array.prototype.diff = function(a) {
	var re=/\s+/g,curI,len=this.length;
    return this.filter(function(e,i) {
    	if(curI!==i) console.log(i,'/',len)
    	return !a.some(function(aE){
    		return noSpaceEqual(aE,e);
    	});
    });
};




// var a=['1','2','  3   '];
// var b=['3','44','45'];

// console.log(a.diff(b))