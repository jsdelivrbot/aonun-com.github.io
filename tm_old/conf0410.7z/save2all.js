const fs=require('fs');
const tmtool=require('./tmtool.js');

var dirname = './ZHO/';
var filenames = fs.readdirSync(dirname);

var results = Object.create(null);
filenames =filenames.filter(function(filename){
	return /\.txt$/ .test(filename);
})

filenames.forEach(function (filename,index){
	results[index]=read(dirname+filename);
	results[index]=getSource(results[index]);
});

function read(path){
	var text =fs.readFileSync(path,{flag:'r',encoding:'UTF-16LE'});
	var tmo = new tmtool.parse(text);
	tmo.parse();
	return tmo;
}

function getSource(tmtoolObject) {
	var r=[], o=tmtoolObject.data;
	for(var i in o) {
		r.push(o[i]);
	}
	// return Array.prototype.map.call(r, function(e){return e[5]+'\t'+e[6];});
	return Array.prototype.map.call(r, function(e){return e[5];});
}




var s=new Set();
for(var i in results) {
	results[i].forEach(function(e){
		s.add(e);
	});
}

fs.writeFileSync('all.txt', Array.from(s).join('\n'), {encoding:'utf8'})










// function tableSort(table,colIndex,) {
// }



// var arr=[
// 	'3.123',
// 	'1.a',
// 	'4.aaaaaaa',
// 	'2.bbbb'
// ];

// function sortByLength(asc) {
// 	asc=asc?1:-1;
// 	return this.sort(function (a,b){
// 		var ia=a.length, ib=b.length;
// 		return asc*(ia>ib ? 1 : (ia===ib ? 0 : -1));
// 	});
// }


// sortByLength.call(arr, false);



// function sortByNumber(asc){
// 	asc=asc?1:-1;
// 	return this.sort(function (a,b){
// 		var b=typeof a && typeof b;
		
// 	});
// }


// 49457 .toString(16)



// '\uFFFF'
// &#49457;


// chr(49457)